function calculate() {
    var username = document.getElementById("username");
    var email = document.getElementById("email");
    var principle = document.getElementById("principle");
    var tenure = document.getElementById("tenure");
    var interest = document.getElementById("interest");
   
    var usernameValid = /^[a-zA-Z0-9]+$/.test(username.value);
    var emailValid = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email.value);
    var principleValid = /^[0-9]+\.?[0-9]*$/.test(principle.value);
    var tenureValid = /^[0-9]+$/.test(tenure.value);
    var interestValid = /^[0-9]+\.?[0-9]*$/.test(interest.value);

     if (!usernameValid) {
        username.classList.add("invalid");
    } else {
        username.classList.remove("invalid");
    }
    if (!emailValid) {
        email.classList.add("invalid");
    } else {
        email.classList.remove("invalid");
    }
 
    if (!principleValid) {
        principle.classList.add("invalid");
    } else {
        principle.classList.remove("invalid");
    }
    if (!tenureValid) {
        tenure.classList.add("invalid");
    } else {
        tenure.classList.remove("invalid");
    }
    if (!interestValid) {
        interest.classList.add("invalid");
    } else {
        interest.classList.remove("invalid");
    }
   
    if ( usernameValid && emailValid && principleValid && tenureValid && interestValid ) {
        var emi = calculateEMI(principle.value, tenure.value, interest.value);
        var calculationTable = document.getElementById("calculationTable");
        var rowCount = calculationTable.rows.length;
        var row = calculationTable.insertRow(rowCount);
        var usernameCell = row.insertCell(0);
        var emailCell = row.insertCell(1);
        var principleCell = row.insertCell(2);
        var tenureCell = row.insertCell(3);
        var interestCell = row.insertCell(4);
        var emiCell = row.insertCell(4);
        
        usernameCell.innerHTML = username.value;
        emailCell.innerHTML = email.value;
        principleCell.innerHTML = principle.value;
        tenureCell.innerHTML = tenure.value;
        interestCell.innerHTML = interest.value;
        emiCell.innerHTML = emi;
        
        
        if (rowCount >= 11) {
            calculationTable.deleteRow(rowCount - 1);
        }
    }
}

function calculateEMI(principle, tenure, interest) {
    var p = parseFloat(principle);
    var r = parseFloat(interest) / 1200;
    var n = parseFloat(tenure) * 12;
    var emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return emi.toFixed(2);
}